dir_ = "./" # directory
data = "asia" # dataset
iter_n = 10 # number of samplings
delta_ratio = 1e5 # delta = delta_lower * delta_ratio
graphs = 5 # numbers of subgraphs for pseudo dataset (n = 5 * graphs)
Solver = "SA" # Annealing Solver (Simulated Annealing (SA), Quantum Annealer (QA), Digital Annealer (DA))
num_reads = 1000 # parameter for SA
annealing_time = 100 # parameter for QA

import pickle
import pandas as pd
from statistics import mean, stdev
from EncodeSolver import Encode_Solver
score_list = []
Hamiltonian_list = []
for num in range(iter_n):
    ES = Encode_Solver()
    if data != "pseudo":
        EC = pd.read_csv(dir_ + data + "/" + data + "_10000_true_" + str(num + 1) + ".csv")
    else:
        EC = pd.read_csv(dir_ + data + "/" + data + "_" + str(graphs) + "_" + str(num + 1) + ".csv")
    ES.encode(EC)
    Hamiltonian_list += [ES.Hamiltonian(delta_ratio=delta_ratio)] 
    if Solver in ["SA", "QA"]:
        score = ES.solver(Solver=Solver, num_reads=num_reads, annealing_time=annealing_time)
        score_list += [score]
file = dir_ + data + "/" + data + "_10000_true" if data != "pseudo" else dir_ + data + "/" + data + "_" + str(graphs)
if Solver in ["SA", "QA"]:
    if iter_n > 1:
        print("Result:")
        print("score:", "mean", mean(score_list), "std", stdev(score_list))
    score_list = pd.DataFrame(score_list)
    score_list.columns = ["score"]
    score_list.to_csv(file + "_" + Solver + ".csv", index=False)
if Solver in ["DA"]:
    with open(file + "_" + Solver + ".pickle", mode='wb') as f:
        pickle.dump(Hamiltonian_list, f)