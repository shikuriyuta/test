import numpy as np
import random
import copy
import networkx as nx
import dimod
from dimod.reference.samplers import ExactSolver

class Encode_Pseudo:
    
    def __init__(self, score_i=100, iter_max=100):
        self.score_i = score_i
        self.iter_max = iter_max
    
    def parent(self, Lambda, n0, n0_, i):
        U = []
        while len(U) < Lambda:
            prob_sub = random.random()
            hoge = set([ii for ii in range(n0, n0_) if random.random() >= prob_sub and ii != i])
            if hoge != set():
                for U_ in copy.copy(U):
                    if hoge <= U_ or hoge >= U_:
                        U.remove(U_)
                U += [hoge]
        return U

    def subgraph(self, n0, delta=1e10):
        U_sub = []
        s0_sub = [self.score_i for i in range(self.n_sub)]
        s1_sub = []
        for i in range(n0, n0 + self.n_sub):    
            Lambda = random.choice(range(0, self.lambda_max + 1))
            U_sub += [self.parent(Lambda, n0, n0 + self.n_sub, i)]
            s1_sub += [[-self.score_i * random.random() for lambda_ in range(Lambda)]]
        s0_sum = sum(s0_sub)
        H = dict()
        for i in range(n0, n0 + self.n_sub):
            for ii in range(len(U_sub[i - n0])):
                H.update({((ii,i),(ii,i)): s1_sub[i - n0][ii]})
            for ii in range(len(U_sub[i - n0])-1):
                for iii in range(ii+1,len(U_sub[i - n0])):
                    H.update({((ii,i), (iii,i)): delta})
        bqm = dimod.BinaryQuadraticModel.from_qubo(H, s0_sum)
        response = ExactSolver().sample(bqm)
        G_sub = []
        S_sub = []
        for res in response:
            edges = []
            fuga = 0
            s = copy.copy(s0_sum)
            for i in range(n0, n0 + self.n_sub):
                hoge = 0
                for ii in range(len(U_sub[i - n0])):
                    if res[(ii,i)] == 1:
                        for iii in list(U_sub[i - n0][ii]):
                            edges += [(iii,i)]
                        s += s1_sub[i - n0][ii]
                        hoge += 1
                if hoge > 1:
                    fuga += 1
            G = nx.DiGraph(edges)
            if fuga == 0 and nx.is_directed_acyclic_graph(G) == True:
                G_sub += [edges]
                S_sub += [s]
        return G_sub, S_sub, U_sub, s1_sub
    
    def generate(self, graphs, n_sub=5, lambda_max=4):
        self.n_sub = n_sub
        self.lambda_max = lambda_max
        n = self.n_sub * graphs
        s0_list = [self.score_i for i in range(n)]
        G_list = []
        S_list = []
        U_list = []
        s1_list = []
        for g in range(graphs):
            G_sub, S_sub, U_sub, s1_sub = self.subgraph(self.n_sub * g)
            G_list += [G_sub]
            S_list += [S_sub]
            U_list += U_sub
            s1_list += s1_sub
        G0 = []
        score0 = 0        
        for g in range(graphs):
            if G_list[g] != []:                
                G0 += G_list[g][0]
                score0 += S_list[g][0]
            else:
                score0 += self.score_i * self.n_sub
        for i in range(len(U_list)):
            iter_ = 0
            while U_list[i] == []:
                Lambda = random.choice(range(0, self.lambda_max + 1))
                U = self.parent(Lambda, 0, n, i)
                s1 = [-self.score_i * random.random() for lambda_ in range(Lambda)]
                if s1 != []:
                    G0_ = copy.copy(G0)
                    for ii in list(U[np.argmin(s1)]):
                        G0_ += [(ii, i)]
                    if nx.is_directed_acyclic_graph(nx.DiGraph(G0_)) == True:
                        G0 = copy.copy(G0_)
                        score0 += min(s1)
                        U_list[i] += U
                        s1_list[i] += s1
                iter_ += 1
                if iter_ == self.iter_max:
                    break
        return U_list, s0_list, s1_list, score0