dir_ = "C:/Users/shiku/Work/Paper/ICML2021/" # directory
iter_n = 10 # number of samplings
graphs = 5 # number of subgraphs

import pandas as pd
from EncodePseudo import Encode_Pseudo
score0_list = []
for num in range(iter_n):
    U_list, s0_list, s1_list, score0 = Encode_Pseudo().generate(graphs, n_sub=5, lambda_max=5)
    df = []
    for (i, U) in enumerate(U_list):
        df += [[i + 1] + [0 for jj in range(3) for j in range(len(U_list))] + [s0_list[i]]]
        for (ii, U_) in enumerate(U):
            hoge = [1 if j in U_ else 0 for j in range(len(U_list))]
            df += [[i + 1] + hoge + [0 for j in range(len(U_list))] + hoge + [s1_list[i][ii] + s0_list[i]]]
    df = pd.DataFrame(df)
    df.columns = ["i"] + ["X"+str(j+1)+"_"+str(jj+1) for jj in range(2) for j in range(len(U_list))] + ["X"+str(j+1) for j in range(len(U_list))] + ["score"]
    df.to_csv(dir_ + "pseudo/pseudo_" + str(graphs) + "_" + str(num + 1) + ".csv", index=False)
    score0_list += [score0]
score0_list = pd.DataFrame(score0_list)
score0_list.columns = ["score0"]
score0_list.to_csv(dir_ + "pseudo/pseudo_" + str(graphs) + "_score0.csv", index=False)